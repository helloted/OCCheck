package checks;


import common.BaseCheck;
import common.SuperChecker;

/**
 * @author camelxiao
 * @version V2.0
 * @date 2020/4/30
 */
@SuperChecker
public class AllInOneChecker extends BaseCheck
{
}
