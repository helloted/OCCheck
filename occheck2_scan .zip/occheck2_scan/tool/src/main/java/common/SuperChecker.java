package common;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * @author camelxiao
 * @version V2.0
 * @date 2020/4/30
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface SuperChecker
{
}
